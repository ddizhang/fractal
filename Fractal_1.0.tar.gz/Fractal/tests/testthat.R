library(testthat)
library(Fractal)

test_check("Fractal")
