kochPattern <-
function()
{
  pts = getPattern()
  modKochPattern(pts)
}
