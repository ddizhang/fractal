plot.stc <-
function(x, ...){
  plot(x[, 1], x[, 2], type = "l", axes=FALSE, xlab = "", ylab = "")
}
