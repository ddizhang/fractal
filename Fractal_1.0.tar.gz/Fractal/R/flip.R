flip <-
function(x, y, x0, a, b){
  x1 = 2*x0-x +a
  y1 = y +b
  return(c(x1, y1))
}
